﻿using System;

namespace DailyKata.Katas
{
    public class PolymorphicRefactoringKata
    {
        private readonly JobTitle _jobTitle;

        public PolymorphicRefactoringKata(JobTitle jobTitle)
        {
            _jobTitle = jobTitle;
        }

        public double GetSalary(JobTitle jobTitle)
        {
            if (Enum.IsDefined(typeof(JobTitle), jobTitle) && jobTitle != JobTitle.Unknown)
                return GetBaseSalary(jobTitle);
            else 
                throw new InvalidOperationException("Invalid job title");
        
        }

        private double GetBaseSalary(JobTitle jobTitle)
        {
            return Convert.ToInt32(jobTitle);
        }
    }

    public enum JobTitle
    {
        Unknown = 0,
        Junior = 100,
        Middle = 175,
        Senior = 195,
        Consultant = 215
    }
}
